//
//  ViewController.swift
//  COMP3097_ShoppingList_Group2
//
//  Created by Tech on 2024-02-20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

